package com.farhad.example.hexagonaltaskmngacl;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HexagonalTaskMngAclApplication {

	public static void main(String[] args) {
		SpringApplication.run(HexagonalTaskMngAclApplication.class, args);
	}

}
