package com.farhad.example.hexagonaltaskmngacl;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HexagonalTaskMngAclApplicationTests {

	@Test
	void contextLoads() {
	}

}
